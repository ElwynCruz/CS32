#ifndef STUDENTWORLD_H_
#define STUDENTWORLD_H_

#include "GameWorld.h"
#include <string>
#include <vector>
// Students:  Add code to this file, StudentWorld.cpp, Actor.h, and Actor.cpp

class Actor;

class Level;


class StudentWorld : public GameWorld
{
public:
    StudentWorld(std::string assetPath);
	virtual ~StudentWorld();
    virtual int init();
    virtual int move();
    virtual void cleanUp();
	bool isOpen(double x, double y) const;
	bool isOverlapping(double x, double y) const;		// takes an x and y coordinate and determines if location is occupied by another actor
private:
	Actor* m_Penelope;
	std::vector<Actor*> m_Actors;
};

#endif // STUDENTWORLD_H_
