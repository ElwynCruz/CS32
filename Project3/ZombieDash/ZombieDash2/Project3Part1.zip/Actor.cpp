#include "Actor.h"
#include "StudentWorld.h"

// Students:  Add code to this file, Actor.h, StudentWorld.h, and StudentWorld.cpp


Actor::Actor(int imageID, int startX, int startY, Direction startDir, int depth, StudentWorld* world)
	:GraphObject(imageID, startX, startY, startDir, depth)
{
	m_world = world;
	m_alive = true;
}

Terrain::Terrain(int id, int startX, int startY, StudentWorld* world)
	:Actor(id, startX, startY, right, 0, world)
{

}


Wall::Wall(int startX, int startY, StudentWorld* world)
	:Terrain(IID_WALL, startX, startY, world)
{

}

void Wall::doSomething()
{
	return;
}




Character::Character(int id, int startX, int startY, StudentWorld* world)
	:Actor(id, startX, startY, right, 0, world)
{

}



Penelope::Penelope(int startX, int startY, StudentWorld* world)
	:Character(IID_PLAYER, startX, startY, world)
{
	m_flameThrowerCount = 0;
	m_landMinesCount = 0;
	m_vaccineCount = 0;
	m_infectionCount = 0;
	m_infected = false;
}

void Penelope::doSomething()
{
	int ch;
	if (getWorld()->getKey(ch))
	{
		double dest_x = getX();
		double dest_y = getY();
		// user hit a key during this tick!
		switch (ch)
		{
			
		case KEY_PRESS_LEFT:
			setDirection(180);
			dest_x = getX() - 4;
			break;
		case KEY_PRESS_RIGHT:
			setDirection(0);
			dest_x = getX() + 4;
			break;
		case KEY_PRESS_UP:
			setDirection(90);
			dest_y = getY() + 4;
			break;
		case KEY_PRESS_DOWN:
			setDirection(270);
			dest_y = getY() - 4;
			break;
			// etc�
		}
		
		if (getWorld()->isOpen(dest_x, dest_y))
			moveTo(dest_x, dest_y);
	}
}