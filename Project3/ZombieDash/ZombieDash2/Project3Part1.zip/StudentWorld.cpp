#include "StudentWorld.h"
#include "GameConstants.h"
#include "Actor.h"
#include "Level.h"
#include <string>
using namespace std;

GameWorld* createStudentWorld(string assetPath)
{
	return new StudentWorld(assetPath);
}

// Students:  Add code to this file, StudentWorld.h, Actor.h and Actor.cpp

StudentWorld::StudentWorld(string assetPath)
	: GameWorld(assetPath)
{
	m_Penelope = nullptr;
}

StudentWorld::~StudentWorld()
{
	cleanUp();
}

int StudentWorld::init()
{
	Level cur(assetPath());
	// getLevel()
	string levelFile = "level01.txt";
	Level::LoadResult loadResult = cur.loadLevel(levelFile);
	if (loadResult == Level::load_fail_file_not_found)
		cerr << "Cannot find level01.txt data file" << endl;
	else if (loadResult == Level::load_fail_bad_format)
		cerr << "Your level was improperly formatted" << endl;
	else if (loadResult == Level::load_success)
	{
		cerr << "Successfully loaded level" << endl;
		for (int i = 0; i < LEVEL_WIDTH; i++)
		{
			for (int j = 0; j < LEVEL_HEIGHT; j++)
			{
				Actor *tempActor;
				Level::MazeEntry ge = cur.getContentsOf(i, j);
				switch (ge)
				{
				case Level::empty:
					break;
				case Level::smart_zombie:
					break;
				case Level::dumb_zombie:
					
					break;
				case Level::player:
					m_Penelope = new Penelope((SPRITE_WIDTH*i), (SPRITE_HEIGHT*j), this);
					break;
				case Level::exit:
					
					break;
				case Level::wall:
					tempActor = new Wall((SPRITE_WIDTH*i), (SPRITE_HEIGHT*j), this);
					m_Actors.push_back(tempActor);
					break;
				case Level::pit:
					
					break;
				}
			}
		}
	}
    return GWSTATUS_CONTINUE_GAME;
}

int StudentWorld::move()
{
	// Give each actor a chance to do something, including Penelope
	int size = m_Actors.size();
	for (int i = 0; i < size; i++)
	{
		if (m_Actors[i]->getAliveStatus())
		{
			m_Actors[i]->doSomething();
			if (!m_Penelope->getAliveStatus())
			{
				decLives();
				return GWSTATUS_PLAYER_DIED;
			}
			//if ()
		}
		m_Penelope->doSomething();
	}
	
    // This code is here merely to allow the game to build, run, and terminate after you hit enter.
    // Notice that the return value GWSTATUS_PLAYER_DIED will cause our framework to end the current level.
    
	return GWSTATUS_CONTINUE_GAME;
}

void StudentWorld::cleanUp()
{
	int numRemaining = m_Actors.size();
	for (int i = 0; i < numRemaining; i++)
	{
		delete m_Actors[i];
	}

	m_Actors.clear();
	delete m_Penelope;
}

bool StudentWorld::isOpen(double x, double y) const
{
	double newBoundX = x + SPRITE_WIDTH - 1;
	double newBoundY = y + SPRITE_HEIGHT - 1;
	for (int i = 0; i < m_Actors.size(); i++)
	{
		double curX = m_Actors[i]->getX();
		double curY = m_Actors[i]->getY();
		double curBoundX = curX + SPRITE_WIDTH - 1;
		double curBoundY = curY + SPRITE_HEIGHT - 1;
		if (curX <= newBoundX && curX >= x)
		{
			if ((curY <= newBoundY && curY >= y) || (curBoundY <= newBoundY && curBoundY >= y))
				return false;
		}
			
		if (curBoundX <= newBoundX && curBoundX >= x)
		{
			if ((curY <= newBoundY && curY >= y) || (curBoundY <= newBoundY && curBoundY >= y))
				return false;
		}
	}
	return true;

}


bool StudentWorld::isOverlapping(double x, double y) const
{
	for (int i = 0; i < m_Actors.size(); i++)
	{
		double deltaX = x - m_Actors[i]->getX();
		double deltaY = y - m_Actors[i]->getY();
		double distance = (deltaX * deltaX) + (deltaY * deltaY);
		if (distance <= 100)
			return true;
	}
	return false;
}
