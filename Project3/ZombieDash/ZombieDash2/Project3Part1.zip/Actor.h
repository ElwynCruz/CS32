#ifndef ACTOR_H_
#define ACTOR_H_

#include "GraphObject.h"

// Students:  Add code to this file, Actor.cpp, StudentWorld.h, and StudentWorld.cpp

class StudentWorld;

class Actor : public GraphObject
{
public:
	Actor(int imageID, int startX, int startY, Direction startDir, int depth, StudentWorld* world);
	virtual void doSomething() = 0;	
	StudentWorld* getWorld() const { return m_world; }

	bool getAliveStatus() const	{ return m_alive; }
	virtual bool isDamageable() const { return true; }								// actors can be damaged unless otherwise noted		   (terrain cannot be damaged)
	virtual bool blocksMovement() const { return false; }							// actors do not block movement unless otherwise noted (only walls and characters)
private:
	StudentWorld* m_world;
	bool m_alive;
};

class Terrain : public Actor
{
public:
	Terrain(int id, int startX, int StartY, StudentWorld* world);
	virtual void doSomething() = 0;
	bool isDamageable() { return false; }										// terrain cannot be damaged
private:

};


class Wall : public Terrain
{
public:
	Wall(int startX, int startY, StudentWorld* world);
	virtual void doSomething();
	virtual bool blocksMovement() const { return true; }
};

class Character : public Actor
{
public:
	Character(int id, int startX, int startY, StudentWorld* world);
	virtual void doSomething() = 0;
	virtual bool blocksMovement() const { return true; }
};

class Penelope : public Character
{
public:
	Penelope(int startX, int startY, StudentWorld* world);
	virtual void doSomething();
	

private:
	int m_flameThrowerCount;
	int m_landMinesCount;
	int m_vaccineCount;
	bool m_infected;
	int m_infectionCount;
};




#endif // ACTOR_H_